# train_model.py
import pandas as pd

# ---------- Activity A: retrieve and inspect the dataset ----------
import io
import os
import zipfile
import urllib.request

ZIP_URL = "https://archive.ics.uci.edu/static/public/320/student+performance.zip"


def read_math_from_zip(zip_bytes):
    """Find student-mat.csv inside the UCI zip (handles a nested student.zip)."""
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as z:
        for name in z.namelist():
            if name.endswith("student-mat.csv"):
                return pd.read_csv(z.open(name), sep=";")
        for name in z.namelist():
            if name.endswith(".zip"):
                return read_math_from_zip(z.read(name))
    raise FileNotFoundError("student-mat.csv not found in the downloaded zip")


def load_dataset():
    # Option 1: a student-mat.csv you downloaded manually (same folder as this script)
    if os.path.exists("student-mat.csv"):
        print("Using local student-mat.csv")
        return pd.read_csv("student-mat.csv", sep=";")
    # Option 2: direct download of the UCI zip (Mathematics file)
    try:
        print("Downloading from UCI...")
        req = urllib.request.Request(ZIP_URL, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=60) as r:
            return read_math_from_zip(r.read())
    except Exception as e:
        print("Direct download failed:", e)
    # Option 3: ucimlrepo (may return the Portuguese file - check the row count!)
    try:
        from ucimlrepo import fetch_ucirepo
        student = fetch_ucirepo(id=320)
        return pd.concat([student.data.features, student.data.targets], axis=1)
    except Exception as e:
        print("ucimlrepo failed:", e)
    raise SystemExit(
        "\nCould not download the dataset.\n"
        "Manual fix: open https://archive.ics.uci.edu/dataset/320/student+performance ,\n"
        "click Download, unzip, and put student-mat.csv in this folder. Then run again."
    )


df = load_dataset()
df.to_csv("student_data.csv", index=False)

print("Rows and columns:", df.shape)   # Mathematics file should be (395, 33)
print(df.head())
print(df.dtypes)
print("Missing values per column:")
print(df.isnull().sum())

# ---------- Activity B: preprocess, train, evaluate ----------
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib

# Target: 1 = at risk (G3 < 10); 0 = not at risk
df = df.drop_duplicates()
y = (df["G3"] < 10).astype(int)

# Never use G3 as a predictor (target leakage)
X = df.drop(columns=["G3"])

numeric_cols = X.select_dtypes(include="number").columns.tolist()
categorical_cols = X.select_dtypes(exclude="number").columns.tolist()

numeric_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler()),
])
categorical_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore")),
])
preprocessor = ColumnTransformer([
    ("numeric", numeric_pipe, numeric_cols),
    ("categorical", categorical_pipe, categorical_cols),
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

model = Pipeline([
    ("preprocessor", preprocessor),
    ("classifier", RandomForestClassifier(
        n_estimators=100, random_state=42, class_weight="balanced"
    )),
])

model.fit(X_train, y_train)
predictions = model.predict(X_test)

accuracy = round(accuracy_score(y_test, predictions), 3)
report = classification_report(
    y_test, predictions,
    target_names=["Not at risk", "At risk"],
    zero_division=0,
)
print("Accuracy:", accuracy)
print(report)

# Save results so they can be copied into the submission
with open("evaluation_results.txt", "w") as f:
    f.write(f"Rows used (after drop_duplicates): {len(df)}\n")
    f.write(f"Accuracy: {accuracy}\n\n")
    f.write(report)

joblib.dump(model, "student_model.pkl")
print("Saved student_model.pkl and evaluation_results.txt")
